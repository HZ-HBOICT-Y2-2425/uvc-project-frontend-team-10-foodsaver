<script></script>
<div class="frame-node Ourmiss-219706">
  <div class="co2-remo-219733"></div>
  <div class="leafBac-219707"></div>
  <div class="leafBac-219708"></div>
  <p class="FoodSave-219710">FoodSaver</p>
  <div class="Line18-219711"></div>
  <p class="Home-219712">Home</p>
  <p class="AboutUs-219713">About Us</p>
  <p class="TipsT-219714">Tips & Tricks</p>
  <p class="Mypantr-219715">My pantry</p>
  <p class="Profile-219716">Profile</p>
  <div class="Rectangl-219717"></div>
  <p class="CO2redu-219718">CO2 reduced!</p>
  <p class="Ourplat-219719">
    Our platform empowers you to make a tangible difference in reducing CO₂
    emissions by reusing leftover ingredients. Every time you cook with what
    you already have, you’re cutting down on the energy and resources needed
    for food production, transportation, and waste disposal. Our app tracks
    your CO₂ savings, giving you a clear view of your positive environmental
    impact. Small changes add up, and together, we’re contributing to a
    greener, healthier planet—one meal at a time.
  </p>
  <div class="image-219720"></div>
</div>
<style>
  .Ourmiss-219706 {
    background-color: #ffffffff;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 80rem;
    height: 45rem;
    border-radius: 0.1875rem 0.1875rem 0.1875rem 0.1875rem;
    opacity: 1;
    overflow: hidden;
    position: relative;
  }
  .Ourmiss-219706 > * {
    position: absolute;
  }
  :global(.frame-node > .Ourmiss-219706) {
    left: 263.8125rem;
    top: -149.625rem;
    position: absolute !important;
  }
  .co2-remo-219733 {
    background-color: transparent;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 12.5625rem;
    height: 10.125rem;
    left: 8.8125rem;
    top: 14rem;
    border-radius: 0rem 0rem 0rem 0rem;
    opacity: 1;
  }
  :global(.group-node > .co2-remo-219733) {
    left: calc(8.8125rem - var(--parentXpos)) !important;
    top: calc(14rem - var(--parentYpos)) !important;
  }
  .leafBac-219707 {
    background-color: transparent;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 12.375rem;
    height: 13.375rem;
    left: 1.980330228805542rem;
    top: 32.6875rem;
    border-radius: 0.75rem 0.75rem 0.75rem 0.75rem;
    opacity: 1;
    transform: rotate(-31.77377614488646deg);
  }
  :global(.group-node > .leafBac-219707) {
    left: calc(1.980330228805542rem - var(--parentXpos)) !important;
    top: calc(32.6875rem - var(--parentYpos)) !important;
  }
  .leafBac-219708 {
    background-color: transparent;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 12.375rem;
    height: 10.3201322555542rem;
    left: 79.19021606445312rem;
    top: 12.715423583984375rem;
    border-radius: 0.75rem 0.75rem 0.75rem 0.75rem;
    opacity: 1;
    transform: rotate(141.54049158814277deg);
  }
  :global(.group-node > .leafBac-219708) {
    left: calc(79.19021606445312rem - var(--parentXpos)) !important;
    top: calc(12.715423583984375rem - var(--parentYpos)) !important;
  }
  .FoodSave-219710 {
    font-size: 1.375rem;
    font-weight: 400;
    text-align: center;
    line-height: 0.9090909090909091;
    letter-spacing: 0.004545454613187097;
    color: #000000ff;
    left: -1.5625rem;
    top: 0.5625rem;
    opacity: 1;
  }
  :global(.group-node > .FoodSave-219710) {
    left: calc(-1.5625rem - var(--parentXpos)) !important;
    top: calc(0.5625rem - var(--parentYpos)) !important;
  }
  .Line18-219711 {
    width: 80.00000762939453rem;
    height: 0.0625rem;
    background-color: #000000ff;
    left: -0.0625rem;
    top: 4.3125rem;
    opacity: 1;
  }
  :global(.group-node > .Line18-219711) {
    left: calc(-0.0625rem - var(--parentXpos)) !important;
    top: calc(4.3125rem - var(--parentYpos)) !important;
  }
  .Home-219712 {
    font-size: 1.5rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 36.6875rem;
    top: 1.25rem;
    opacity: 1;
  }
  :global(.group-node > .Home-219712) {
    left: calc(36.6875rem - var(--parentXpos)) !important;
    top: calc(1.25rem - var(--parentYpos)) !important;
  }
  .AboutUs-219713 {
    font-size: 1.5rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 42.6875rem;
    top: 1.375rem;
    opacity: 1;
  }
  :global(.group-node > .AboutUs-219713) {
    left: calc(42.6875rem - var(--parentXpos)) !important;
    top: calc(1.375rem - var(--parentYpos)) !important;
  }
  .TipsT-219714 {
    font-size: 1.5rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 50.0625rem;
    top: 1.375rem;
    opacity: 1;
  }
  :global(.group-node > .TipsT-219714) {
    left: calc(50.0625rem - var(--parentXpos)) !important;
    top: calc(1.375rem - var(--parentYpos)) !important;
  }
  .Mypantr-219715 {
    font-size: 1.5rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 61.8125rem;
    top: 1.375rem;
    opacity: 1;
  }
  :global(.group-node > .Mypantr-219715) {
    left: calc(61.8125rem - var(--parentXpos)) !important;
    top: calc(1.375rem - var(--parentYpos)) !important;
  }
  .Profile-219716 {
    font-size: 1.5rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 71.25rem;
    top: 1.375rem;
    opacity: 1;
  }
  :global(.group-node > .Profile-219716) {
    left: calc(71.25rem - var(--parentXpos)) !important;
    top: calc(1.375rem - var(--parentYpos)) !important;
  }
  .Rectangl-219717 {
    background-color: #b5c1b4a6;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 67.9375rem;
    height: 32rem;
    left: 5.9375rem;
    top: 7.0625rem;
    border-radius: 1.4375rem 1.4375rem 1.4375rem 1.4375rem;
    opacity: 1;
    box-shadow: 0px 4px 4px 0px #00000040;
  }
  :global(.group-node > .Rectangl-219717) {
    left: calc(5.9375rem - var(--parentXpos)) !important;
    top: calc(7.0625rem - var(--parentYpos)) !important;
  }
  .CO2redu-219718 {
    font-size: 3rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 31.4375rem;
    top: 9.4375rem;
    opacity: 1;
  }
  :global(.group-node > .CO2redu-219718) {
    left: calc(31.4375rem - var(--parentXpos)) !important;
    top: calc(9.4375rem - var(--parentYpos)) !important;
  }
  .Ourplat-219719 {
    font-size: 1.25rem;
    font-weight: 400;
    text-align: left;
    line-height: normal;
    letter-spacing: 0;
    color: #000000ff;
    left: 10.6875rem;
    top: 16.9375rem;
    opacity: 1;
  }
  :global(.group-node > .Ourplat-219719) {
    left: calc(10.6875rem - var(--parentXpos)) !important;
    top: calc(16.9375rem - var(--parentYpos)) !important;
  }
  .image-219720 {
    background-color: transparent;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
    width: 25.8125rem;
    height: 17.25rem;
    left: 43.1875rem;
    top: 16.9375rem;
    border-radius: 0.9375rem 0.9375rem 0.9375rem 0.9375rem;
    opacity: 1;
    box-shadow: 0px 4px 4px 0px #00000040;
  }
  :global(.group-node > .image-219720) {
    left: calc(43.1875rem - var(--parentXpos)) !important;
    top: calc(16.9375rem - var(--parentYpos)) !important;
  }
</style>