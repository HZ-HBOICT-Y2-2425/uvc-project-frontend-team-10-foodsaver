<script>
	import '../../app.css';
</script>

<!-- 


<script lang="ts">
  

  

  

    let className = '';
  export { className as class } 
  </script>
    
  <div
  class="items-start w-full flex {className}"
  
  
  ><div
  class="pb-[38px] gap-y-[7.5px] overflow-clip flex-shrink-0 flex h-full w-full pt-9 flex-col bg-white items-center px-96"
  
  
  ><div
  class="flex justify-center items-center"
  
  
  ><div
  class="[max-width:239px] flex justify-center pl-7 flex-grow items-center"
  
  
  ><div
  class="tracking-[0.1px] text-[35px] font-bree-serif h-[51px] leading-5 flex items-center justify-center text-center flex-grow"
  
  
  ><p
  
  
  
  >FoodSaver</p></div></div></div><div
  class="flex justify-end pt-12 flex-col items-center"
  
  
  ><div
  class="pl-[22px] flex justify-end items-center"
  
  
  ><div
  class="[box-shadow:_0px_1px_3px_1px_rgba(0,0,0,0.15)] bg-purple-50 drop-shadow-lg tracking-[-0.43px] leading-[22px] font-inter text-[17px] py-[8.5px] text-center font-bold px-24 rounded-lg"
  
  
  ><span
  
  
  
  >New to FoodSaver? <span
  class="text-[#0000ffe5] text-center"
  
  
  >Sign up</span></span></div></div></div><div
  class="[max-width:504px] pt-7 self-stretch"
  
  
  ><div
  class="tracking-[0px] leading-[1.4] text-neutral-900 font-inter"
  
  
  >Username</div></div><div
  class="w-[504px] border-y-[gainsboro] border-x-[gainsboro] flex-shrink-0 h-10 bg-white border border-solid rounded-lg"
  
  
  /><div
  class="[max-width:504px] pt-3.5 self-stretch"
  
  
  ><div
  class="tracking-[0px] leading-[1.4] text-neutral-900 font-inter"
  
  
  >Password</div></div><div
  class="w-[504px] border-y-[gainsboro] border-x-[gainsboro] flex-shrink-0 h-10 bg-white border border-solid rounded-lg"
  
  
  /><div
  class="flex justify-center pt-5 items-end"
  
  
  ><div
  class="pr-[22px] flex items-center"
  
  
  ><div
  class="bg-purple-200 tracking-[0.1px] font-roboto py-[7.5px] px-[102px] rounded-[100px] text-center leading-5 font-medium text-sm"
  
  
  >Log in</div></div></div><div
  class="[max-width:504px] pt-[15px] flex pr-11 pl-48 self-stretch items-end"
  
  
  ><div
  class="tracking-[0.1px] font-roboto font-medium leading-5 text-sm flex-grow"
  
  
  >Continue with...</div></div><div
  class="pt-[7.5px] pl-[3px] flex justify-center items-end"
  
  
  ><div
  class="min-[1270px]:flex-nowrap flex flex-wrap justify-center gap-x-20 gap-y-6 items-center"
  
  
  ><div
  class="pt-[5px] flex justify-end flex-col items-center"
  
  
  ><img
  class="w-[52px] flex-shrink-0 h-11 object-center object-cover rounded-full"
  
  src="/assets/sprint-google.png"
  loading="lazy"
  /></div><div
  class="gap-x-[30px] flex justify-center items-center"
  
  
  ><div
  class="flex self-stretch flex-col items-center"
  
  
  ><img
  class="flex-shrink-0 h-12 w-14 object-center object-cover rounded-full"
  
  src="/sprint-facebook.png"
  loading="lazy"
  /></div><div
  class="bg-sprint-apple flex-shrink-0 h-14 w-36 bg-no-repeat bg-contain bg-center"
  
  
  /></div></div></div><div
  class="flex justify-center pt-5 items-end"
  
  
  ><div
  class="pr-[15px] flex items-center"
  
  
  ><div
  class="bg-purple-200 tracking-[0.1px] font-roboto rounded-[100px] text-center leading-5 font-medium text-sm py-2 px-28"
  
  
  >Continue as Guest</div></div></div><div
  class="pl-[0.5px] flex pt-7 pr-11 items-end"
  
  
  ><div
  class="min-[1270px]:flex-nowrap tracking-[-0.43px] leading-[22px] text-[#0000ffe5] text-[17px] font-inter gap-y-[11px] flex flex-wrap justify-center gap-x-32 items-center"
  
  
  ><div
  
  
  
  ><span
  
  
  
  >Forget <span
  class="text-[blue]"
  
  
  >your </span>password?</span></div><div
  
  
  
  >Problems logging in?</div></div></div><div
  class="before:[transform:rotate(-32.79deg)] before:[background-position:-7.27px_-85px] before:[background-size:159%_137%] before:[content:''] flex-shrink-0 top-0 right-0 h-44 w-40 max-h-full max-w-full z-0 relative rounded-xl before:z-[-1] before:bg-leaf-background-removed before:bg-no-repeat before:absolute before:inset-0"
  
  
  /><div
  class="before:[transform:rotate(22deg)] before:[background-position:-130.63px_-5.2px] before:[background-size:156%_143%] before:[content:''] flex-shrink-0 left-0 bottom-0 h-40 w-40 max-h-full max-w-full z-0 relative rounded-xl before:z-[-1] before:bg-leaf-background-removed before:bg-no-repeat before:absolute before:inset-0"
  
  
  /></div></div>
  
  
  <!--
    This component was generated from Figma with FireJet. 
    Learn more at https://www.firejet.io
    
    README:
    The output code may look slightly different when copied to your codebase. To fix this:
    1. Include the necessary fonts. The required fonts are imported from index.html
    2. Include the global styles. They can be found in styles.css
    
    Note: Step 2 is not required for tailwind.css output
  -->
   -->

<!-- <script>
   <div className="LogIn w-96 h-96 relative bg-white">
    <img className="LeafBackgroundRemoved9 w-48 h-40 left-[-34.30px] top-[795px] absolute origin-top-left rotate-[26.51deg] rounded-xl" src="https://via.placeholder.com/198x165" />
    <div className="InputField w-96 h-32 left-[401px] top-[217px] absolute flex-col justify-start items-start gap-2 inline-flex">
      <div className="Label self-stretch text-Text-Default-Default text-base font-normal font-['Inter'] leading-snug">Username</div>
      <div className="Input self-stretch px-4 py-3 bg-Background-Default-Default rounded-lg border border-Border-Default-Default justify-start items-center inline-flex">
        <div className="Value grow shrink basis-0"></div>
      </div>
    </div>
    <div className="InputField w-96 h-32 left-[401px] top-[309px] absolute flex-col justify-start items-start gap-2 inline-flex">
      <div className="Label self-stretch text-Text-Default-Default text-base font-normal font-['Inter'] leading-snug">Password</div>
      <div className="Input self-stretch px-4 py-3 bg-Background-Default-Default rounded-lg border border-Border-Default-Default justify-start items-center inline-flex">
        <div className="Value grow shrink basis-0"></div>
      </div>
    </div>
    <div className="ForgetYourPassword left-[401px] top-[660px] absolute"><span style="text-blue-700/95 text-base font-normal font-['Inter'] leading-snug">Forget </span><span style="text-blue-700 text-base font-normal font-['Inter'] leading-snug">your</span><span style="text-blue-700/95 text-base font-normal font-['Inter'] leading-snug"> password?</span></div>
    <div className="2024FoodsaverAllRightsReserved left-[106px] top-[903px] absolute text-neutral-500 text-sm font-medium font-['Roboto'] leading-tight tracking-tight">© 2024 FoodSaver. All rights reserved.<br/></div>
    <div className="ProblemsLoggingIn left-[703px] top-[660px] absolute text-blue-700/95 text-base font-normal font-['Inter'] leading-snug">Problems logging in?</div>
    <div className="IfYouChooseToLogInWithGoogleFacebookOrAppleAndAreNotAlreadyAFoodsaverUserYouWillBeRegisteredAndYouAgreeToFoodsaverSTermsConditionsAndPrivacyPolicy w-80 left-[39px] top-[763px] absolute"><span style="text-black text-xs font-normal font-['Inter'] leading-snug">If you choose to log in with Google, Facebook, or Apple and are not already a FoodSaver user, you will be registered, and you agree to FoodSaver's </span><span style="text-blue-700/95 text-xs font-normal font-['Inter'] leading-snug">Terms & Conditions</span><span style="text-black text-xs font-normal font-['Inter'] leading-snug"> and </span><span style="text-blue-700/95 text-xs font-normal font-['Inter'] leading-snug">Privacy Policy</span><span style="text-black text-xs font-normal font-['Inter'] leading-snug">.</span></div>
    <div className="ContinueWith w-72 h-6 left-[586px] top-[464px] absolute text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">Continue with...</div>
    <div className="SprintGoogle w-12 h-11 left-[475px] top-[514px] absolute justify-center items-center inline-flex">
      <img className="SprintGoogle w-12 h-11 rounded-full" src="https://via.placeholder.com/52x44" />
    </div>
    <img className="SprintApple w-36 h-14 left-[693px] top-[505px] absolute" src="https://via.placeholder.com/140x57" />
    <div className="SprintFacebook w-14 h-12 left-[609px] top-[508px] absolute justify-center items-center inline-flex">
      <img className="SprintFacebook w-14 h-12 rounded-3xl" src="https://via.placeholder.com/54x50" />
    </div>
    <div className="AssistiveChip w-96 h-10 left-[456px] top-[143px] absolute bg-Schemes-Surface Container Low rounded-lg shadow justify-center items-center inline-flex">
      <div className="StateLayer px-4 py-1.5 justify-center items-center gap-2 flex">
        <div className="LabelText text-center"><span style="text-black text-base font-bold font-['Inter'] leading-snug">New to FoodSaver? </span><span style="text-blue-700/95 text-base font-bold font-['Inter'] leading-snug">Sign up</span></div>
      </div>
    </div>
    <div className="Foodsaver w-52 h-12 left-[562px] top-[36px] absolute text-center text-black text-4xl font-normal font-['Bree Serif'] leading-tight tracking-tight">FoodSaver</div>
    <div className="Button w-60 h-9 left-[520px] top-[407px] absolute bg-Schemes-Primary Container rounded-full flex-col justify-center items-center gap-2 inline-flex">
      <div className="StateLayer self-stretch grow shrink basis-0 px-6 py-2.5 justify-center items-center gap-2 inline-flex">
        <div className="LabelText text-center text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">Log in</div>
      </div>
    </div>
    <div className="Button w-80 h-9 left-[475px] top-[589px] absolute bg-Schemes-Primary Container rounded-full flex-col justify-center items-center gap-2 inline-flex">
      <div className="StateLayer self-stretch grow shrink basis-0 px-6 py-2.5 justify-center items-center gap-2 inline-flex">
        <div className="LabelText text-center text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">Continue as Guest</div>
      </div>
    </div>
    <img className="LeafBackgroundRemoved8 w-48 h-40 left-[1114px] top-[45.23px] absolute origin-top-left rotate-[-32.79deg] rounded-xl" src="https://via.placeholder.com/198x165" />
    <img className="LeafBackgroundRemoved10 w-48 h-44 left-[-20px] top-[555px] absolute origin-top-left rotate-[22.11deg] rounded-xl" src="https://via.placeholder.com/196x170" />
  </div>
</script> -->

<!-- <script>
    // Si necesitas lógica, inclúyela aquí
  </script> -->
  
  <div class="LogIn w-96 h-96 relative bg-white">
    <img class="LeafBackgroundRemoved9 w-48 h-40 left-[-34.30px] top-[795px] absolute origin-top-left rotate-[26.51deg] rounded-xl" 
         src="../../../leaf-backgorund1.png" 
         alt="Leaf Background" />
         
    <div class="InputField w-96 h-32 left-[401px] top-[217px] absolute flex-col justify-start items-start gap-2 inline-flex">
      <div class="Label self-stretch text-Text-Default-Default text-base font-normal font-['Inter'] leading-snug">Username</div>
      <div class="Input self-stretch px-4 py-3 bg-Background-Default-Default rounded-lg border border-Border-Default-Default justify-start items-center inline-flex">
        <div class="Value grow shrink basis-0"></div>
      </div>
    </div>
  
    <div class="InputField w-96 h-32 left-[401px] top-[309px] absolute flex-col justify-start items-start gap-2 inline-flex">
      <div class="Label self-stretch text-Text-Default-Default text-base font-normal font-['Inter'] leading-snug">Password</div>
      <div class="Input self-stretch px-4 py-3 bg-Background-Default-Default rounded-lg border border-Border-Default-Default justify-start items-center inline-flex">
        <div class="Value grow shrink basis-0"></div>
      </div>
    </div>
  
    <div class="ForgetYourPassword left-[401px] top-[660px] absolute">
      <span class="text-blue-700/95 text-base font-normal font-['Inter'] leading-snug">Forget </span>
      <span class="text-blue-700 text-base font-normal font-['Inter'] leading-snug">your</span>
      <span class="text-blue-700/95 text-base font-normal font-['Inter'] leading-snug"> password?</span>
    </div>
  
    <div class="2024FoodsaverAllRightsReserved left-[106px] top-[903px] absolute text-neutral-500 text-sm font-medium font-['Roboto'] leading-tight tracking-tight">
      © 2024 FoodSaver. All rights reserved.
    </div>
  
    <div class="ProblemsLoggingIn left-[703px] top-[660px] absolute text-blue-700/95 text-base font-normal font-['Inter'] leading-snug">
      Problems logging in?
    </div>
  
    <div class="IfYouChooseToLogInWithGoogleFacebookOrAppleAndAreNotAlreadyAFoodsaverUserYouWillBeRegisteredAndYouAgreeToFoodsaverSTermsConditionsAndPrivacyPolicy w-80 left-[39px] top-[763px] absolute">
      <span class="text-black text-xs font-normal font-['Inter'] leading-snug">
        If you choose to log in with Google, Facebook, or Apple and are not already a FoodSaver user, you will be registered, and you agree to FoodSaver's 
      </span>
      <span class="text-blue-700/95 text-xs font-normal font-['Inter'] leading-snug">Terms & Conditions</span>
      <span class="text-black text-xs font-normal font-['Inter'] leading-snug"> and </span>
      <span class="text-blue-700/95 text-xs font-normal font-['Inter'] leading-snug">Privacy Policy</span>
      <span class="text-black text-xs font-normal font-['Inter'] leading-snug">.</span>
    </div>
  
    <div class="ContinueWith w-72 h-6 left-[586px] top-[464px] absolute text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">
      Continue with...
    </div>
  
    <div class="SprintGoogle w-12 h-11 left-[475px] top-[514px] absolute justify-center items-center inline-flex">
      <img class="SprintGoogle w-12 h-11 rounded-full" src="../../../sprint-google.png" alt="Google" />
    </div>
  
    <img class="SprintApple w-14 h-14 left-[675px] top-[505px] absolute" src="../../../sprint-apple.png" alt="Apple" />
    
    <div class="SprintFacebook w-14 h-12 left-[575px] top-[508px] absolute justify-center items-center inline-flex">
      <img class="SprintFacebook w-14 h-12 rounded-3xl" src="../../../sprint-facebook.png" alt="Facebook" />
    </div>
  
    <div class="AssistiveChip w-96 h-10 left-[456px] top-[143px] absolute bg-Schemes-Surface Container Low rounded-lg shadow justify-center items-center inline-flex">
      <div class="StateLayer px-4 py-1.5 justify-center items-center gap-2 flex">
        <div class="LabelText text-center">
          <span class="text-black text-base font-bold font-['Inter'] leading-snug">New to FoodSaver? </span>
          <span class="text-blue-700/95 text-base font-bold font-['Inter'] leading-snug">Sign up</span>
        </div>
      </div>
    </div>
  
    <div class="Foodsaver w-52 h-12 left-[562px] top-[36px] absolute text-center text-black text-4xl font-normal font-['Bree Serif'] leading-tight tracking-tight">
      FoodSaver
    </div>
  
    <div class="Button w-60 h-9 left-[520px] top-[407px] absolute bg-Schemes-Primary Container rounded-full flex-col justify-center items-center gap-2 inline-flex">
      <div class="StateLayer self-stretch grow shrink basis-0 px-6 py-2.5 justify-center items-center gap-2 inline-flex">
        <div class="LabelText text-center text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">Log in</div>
      </div>
    </div>
  
    <div class="Button w-80 h-9 left-[475px] top-[589px] absolute bg-Schemes-Primary Container rounded-full flex-col justify-center items-center gap-2 inline-flex">
      <div class="StateLayer self-stretch grow shrink basis-0 px-6 py-2.5 justify-center items-center gap-2 inline-flex">
        <div class="LabelText text-center text-black text-sm font-medium font-['Roboto'] leading-tight tracking-tight">Continue as Guest</div>
      </div>
    </div>
  
    <img class="LeafBackgroundRemoved8 w-48 h-40 left-[1114px] top-[45.23px] absolute origin-top-left rotate-[-32.79deg] rounded-xl" 
         src="../../../leaf-background2.png" alt="Leaf Background 8" />
    <img class="LeafBackgroundRemoved10 w-48 h-44 left-[-20px] top-[555px] absolute origin-top-left rotate-[22.11deg] rounded-xl" 
         src="../../../leaf-background2.png" alt="Leaf Background 10" />
  </div>
  